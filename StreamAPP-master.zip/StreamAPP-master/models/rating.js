'use strict';
module.exports = (sequelize, DataTypes) => {
  
  const  Rating = sequelize.define('Rating', {
    video_id: DataTypes.STRING,
    offset1: DataTypes.INTEGER,
    offset2: DataTypes.INTEGER
  }, {});
  Rating.associate = function(models) {
    // associations can be defined here
 //Rating.hasOne(models.Video,{foreignkey:'videoId'})
  };
  return Rating;
};