'use strict';
module.exports = (sequelize, DataTypes) => {
  
  const Comment = sequelize.define('Comment', {
    user_id: DataTypes.STRING,
    video_id: DataTypes.STRING,
    comment: DataTypes.TEXT
  }, {});
  Comment.associate = function(models) {
    // associations can be defined here
   // Comment.hasOne(models.User,{foreignkey:'userId'});
    //Comment.hasOne(models.Video,{foreigkey:'videosId'});

  };
  return Comment;
};