'use strict';
module.exports = (sequelize, DataTypes) => {
  
  const  Video = sequelize.define('Video', {
    title: DataTypes.STRING,
    publisher: DataTypes.STRING,
    producer: DataTypes.STRING,
    genre: DataTypes.STRING,
    age_rating: DataTypes.INTEGER,
    user_id: DataTypes.INTEGER
  }, {});
  Video.associate = function(models) {
    // associations can be defined her
 // Video.hasOne(models.User,{foreignkey:'userId'});
  //Video.hasOne(models.Rating,{foreignkey:'videoId'});
  //Video.hasOne(models.View,{foreignkey:'videoId'});
  //Video.hasMany(models.Comment,{foreignkey:'videosId'});
  };
  return Video;
};