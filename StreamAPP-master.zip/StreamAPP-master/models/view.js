'use strict';
module.exports = (sequelize, DataTypes) => {
  
  const  View = sequelize.define('View', {
    video_id: DataTypes.STRING,
    offset: DataTypes.INTEGER
  }, {});
  View.associate = function(models) {
    // associations can be defined here
   // View.hasOne(models.Video,{foreignkey:'videoId'});
  };
  return View;
};