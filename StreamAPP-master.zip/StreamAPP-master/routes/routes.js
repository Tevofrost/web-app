const user_ctrl = require('./../controllers/user_ctrl')
const video_ctrl = require('./../controllers/video_ctrl')
const comment_ctrl = require('./../controllers/comment_ctrl');


module.exports =function(express){
    const route = express.Router();
    //get all users
    route.get("/get_users",user_ctrl.getAll);
    //add users
    route.post("/add_user",user_ctrl.save);
    //get one user
    route.get("/get_user",user_ctrl.get);
   //update user
    route.put("/update_user",user_ctrl.update);
   //delete user
   route.delete("/delete_user",user_ctrl.delete);
   



   //add video
  // route.post("/add_video",video_ctrl.save);
   route.get("/get_video",video_ctrl.get);
   route.get("/get_allmovies",video_ctrl.getAll);
   route.get('/get_comedy',video_ctrl.getAllComedy);
   route.get('/get_action',video_ctrl.getAllAction);
   route.get('/get_cartoon',video_ctrl.getAllCartoon);
   route.get('/get_thriller',video_ctrl.getAllThriller);
   route.get('/get_horror',video_ctrl.getAllHorror);

   route.post("/add_comment",comment_ctrl.save);
   route.get("/get_comments",comment_ctrl.get);
////mmmmmmh yeaaaah the rest is easy fam 
    return route;
}