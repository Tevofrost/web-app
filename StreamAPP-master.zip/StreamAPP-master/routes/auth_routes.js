// auth_routes.js
const auth_ctrl = require("./../controllers/auth_ctrl");

module.exports = function(app, passport) {
  // Define your authentication routes and logic here
  app.get('/', auth_ctrl.signin);
  app.get('/creator', isLoggedIn, auth_ctrl.creator);
  app.get('/logout', auth_ctrl.logout);

  app.post('/signup', passport.authenticate('local-sigup', {
    successRedirect: '/creator',
    failureRedirect: '/'
  }));

  app.post('/signin', passport.authenticate('local-signin', {
    successRedirect: '/creator',
    failureRedirect: '/'
  }));

  function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) {
      return next();
    }
    res.redirect('/');
  }
};
