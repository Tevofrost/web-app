var bCrypt =require('bcrypt');

module.exports = function (passport ,user){
    var User = user;
    var LocalStrategy = require('passport-local').Strategy;
    passport.use('local-signup',new LocalStrategy({
        usernameField:'email',
        passwordField:'password',
        passReqToCallback:true
    },
    function(req,email,password,done){
        var generateHash = function(password){
            return bCrypt.hashSync(password, bCrypt.genSaltSync(8),null);

        };
        User.findOne({
            where:{
                email:email
            }
        }).then(function(user){
            if (user){
                return done(null,false,{
                    message:'Email is taken'

                });

            }else
            {
                var UserPassword = generateHash(password);
                var data = {
                    email:email,
                    password:UserPassword,
                    firstName:req.body.firstName,
                    lastName:req.body.lastName,
                    DOB:req.body.DOB,
                    Role:req.body.Role

                };
                User.create(data).then(function(newUser,created){
                    if(!newUser){
                        return done(null , false);

                    }
                    if(newUser){
                        return done(null,newUser);

                    }
                });
            }
        });
    }
    
    
    ));

passport.use('local-signin',new LocalStrategy(
    {
        usernameField:'email',
        passwordField:'password',
        passReqToCallback:true

    } ,
    function (req,email,password,done){
        var User =user;
        var isValidPassword = function(userpass,password){
            return bCrypt.compareSync(password,userpass);

        }
        User.findOne({
            where:{
                email:email
            }
        }).then(function(user){
            if(!user){
                return done(null,false,{
                    message:'Email doesnt exist'
                });
            }
            if(!isValidPassword(user.password,password))
            {
                return done (null,false,{
                    message:'incorect password',
                });
            }
            var userInfo=user.get();
            return done(null,userInfo);
        }).catch(function(err){
            console.log("error",err);
            return done(null,false,{
                message:'something went wrong'
            });
        });
    }
));
passport.serializeUser(function (user,done){
    done(null,user.id);
});
passport.deserializeUser(function(id, done) {
    User.findOne({
        where: {
            id: id
        }
    }).then(function(user) {
        if (user) {
            done(null, user.get());
        } else {
            done(null, false, { message: 'Incorrect credentials.' });
        }
    }).catch(function(err) {
        done(err, false, { message: 'Something went wrong.' });
    });
});
}