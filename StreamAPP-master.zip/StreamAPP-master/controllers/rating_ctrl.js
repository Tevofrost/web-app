const {Rating,Sequelize} = require("./../models");
let self= {};
self.getAll =async(req,res)=>{
    try{
        let data = await Rating.findAll({
            attributes:["id","video_id","offset1","offset2"],

        })
        return res.json({
            status: "ok",
            data: data,
          });

    }catch(error){
        res.status(500).json({
            status: "error",
            data: error,
          });
    }
}
//
self.get =async(req,res)=>{
    try{
        let email = req.query.email;
        let data = await Rating.findOne({
            attributes:["id","video_id","offset1","offset2"],
            where:{
                email:email
            },
        });
        if (!data) {
            return res.status(404).json({
            status: "error",
            message: "Rating not found",
           });
               }
           return res.json({
             status: "ok",
             data: data,
           });

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.save =async(req,res)=>{
    try{
        let body = req.body;
        let data = await Rating.create(body);
        return res.json({
            status:"ok",
            data:data,
        })

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        }) 
    }
}
self.update =async(req,res)=>{
    try{
        let email = req.query.email;
        let body = req.body;
        let data = await Rating.update(body,{
            where:{
                email:email
            },
        })
        return res.json({
            status:"ok",
            data:data,
        })

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.delete =async(req,res)=>{
    try{
        let email = req.query.email;
        let data = await Rating.destroy({
            where: {
                email: email
              },
        })
        return res.json({
            status: "ok",
            message: "User deleted successfully",data
          });

    }catch(error){
        res.status(500).json({
            status: "error",
            data: error
          });
    }
}
module.exports = self;