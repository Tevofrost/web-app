var exports = module.export={}
exports.signup =function (req,res){
    res.render('main');

}
exports.signin = function(req,res){
    res.render('main')
};
exports.creator = function(req,res){
    res.render('creator',{firstName:req.user.firstName,
    lastName:req.user.lastName,
    DOB:req.body.DOB,
    Role:req.body.Role
    
})
}
exports.logout = function (req,res){

req.session.destroy(function(err){
    res.redirect('/');
});
}