const {Comment,Sequelize} = require("./../models");
let self= {};
self.getAll =async(req,res)=>{
    try{
        let data = await Comment.findAll({
            attributes:["id","user_id","video_id","comment"],
        })
        return res.json({
            status: "ok",
            data: data,
          });
    }catch (error) {
        res.status(500).json({
          status: "error",
          data: error,
        });
      }
}
//
self.get =async(req,res)=>{
    try{
        let videoId = req.query.videoID;
        let data = await Comment.findOne({
            attributes:["id","user_id","video_id","comment"],
            where:{
                video_id:videoId
            },
        })
        if (!data) {
            return res.status(404).json({
            status: "error",
            message: "Comments not found",
           });
               }
           return res.json({
             status: "ok",
             data: data,
           });
    

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.save =async(req,res)=>{
    try{
        let body = req.body;
        let data = await Comment.create(body);
        return res.json({
            status:"ok",
            data:data,
        })

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
self.update =async(req,res)=>{
    try{
        let email = req.query.email;
        let body = req.body;
        let data = await Comment.update(body,{
            where:{
                email:email
            },
        })
        return res.json({
            status:"ok",
            data:data,
        })

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.delete =async(req,res)=>{
    try{
        let email = req.query.email;
        let data = await Comment.destroy({
            where: {
                email: email
              },
        });
        return res.json({
            status: "ok",
            message: " Comment deleted successfully",data
          });

    }catch(error){
        res.status(500).json({
            status: "error",
            data: error
          });
    }
}
module.exports = self;