const {User,Sequelize} = require("./../models");
let self= {};
self.getAll = async (req, res) => {
    try {
      let data = await User.findAll({
        attributes: ["id", "firstName", "lastName", "email", "password", "DOB", "Role"],
      });
      return res.json({
        status: "ok",
        data: data,
      });
    } catch (error) {
      res.status(500).json({
        status: "error",
        data: error,
      });
    }
  };
//
self.get = async(req,res)=>{
    try{
        let email = req.query.email;
        let data = await  User.findOne({
            attributes:["id","firstName","lastName","email","password","DOB","Role"],
            where:{
                email:email
            },
        });

            if (!data) {
             return res.status(404).json({
             status: "error",
             message: "User not found",
            });
                }
            return res.json({
              status: "ok",
              data: data,
            });
     
    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
        
    }
}
//
self.save = async(req,res)=>{
    try{
        let body = req.body;
        let data = await User.create(body);
        return res.json({
            status:"ok",
            data:data,
        })
    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
self.update = async(req,res)=>{
    try{
        let email = req.query.email;
        let body = req.body;
        let data = await User.update(body,{
            where:{
                email:email
            },
        });
        return res.json({
            status:"ok",
            data:data,
        })

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.delete = async (req, res) => {
  try {
    let email = req.query.email;
    let data = await User.destroy({
      where: {
        email: email
      },
    });
    return res.json({
      status: "ok",
      message: "User deleted successfully",data
    });
  } catch (error) {
    res.status(500).json({
      status: "error",
      data: error
    });
  }
};
module.exports = self;