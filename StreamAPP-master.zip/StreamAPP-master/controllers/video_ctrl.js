const {Video,Sequelize} = require("./../models");
let self= {};
self.getAll =async(req,res)=>{
    try{
        let data = await Video.findAll({
            attributes:["id","title","publisher","producer","genre","age_rating","user_id"],
           
        });
        return res.json({
            status: "ok",
            data: data,
          });

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//standing on bidinesss
self.getAllComedy =async(req,res)=>{
    try{
        let data = await Video.findAll({
            attributes:["id","title","publisher","producer","genre","age_rating","user_id"],
            where:{
                genre:'comedy'
            },
        });
        return res.json({
            status: "ok",
            data: data,
          });

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.getAllAction =async(req,res)=>{
    try{
        let data = await Video.findAll({
            attributes:["id","title","publisher","producer","genre","age_rating","user_id"],
            where:{
                genre:'action'
            },
        });
        return res.json({
            status: "ok",
            data: data,
          });

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.getAllHorror =async(req,res)=>{
    try{
        let data = await Video.findAll({
            attributes:["id","title","publisher","producer","genre","age_rating","user_id"],
            where:{
                genre:'horror'
            },
        });
        return res.json({
            status: "ok",
            data: data,
          });

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.getAllThriller =async(req,res)=>{
    try{
        let data = await Video.findAll({
            attributes:["id","title","publisher","producer","genre","age_rating","user_id"],
            where:{
                genre:'thriller'
            },
        });
        return res.json({
            status: "ok",
            data: data,
          });

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.getAllCartoon =async(req,res)=>{
    try{
        let data = await Video.findAll({
            attributes:["id","title","publisher","producer","genre","age_rating","user_id"],
            where:{
                genre:'cartoon'
            },
        });
        return res.json({
            status: "ok",
            data: data,
          });

    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.get =async(req,res)=>{
    try{
        let title = req.query.title;
        let data = await Video.findOne({
            attributes:["id","title","publisher","producer","genre","age_rating","user_id"],
            where:{
                title:title
            },
        });
        if (!data) {
            return res.status(404).json({
            status: "error",
            message: "Video not found",
           });
               }
           return res.json({
             status: "ok",
             data: data,
           });
    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
/*self.save =async(req,res,videoDetails)=>{
    try{
       let body = req.body;
       let data = await Video.create(body);
       return res.json({
        status:"ok",
        data:data,
    })
    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}*/
self.update =async(req,res)=>{
    try{
        let email = req.query.email;
        let body = req.body;
        let data = await Video.update(body,{
             where:{
                email:email
            }
        });
        return res.json({
            status:"ok",
            data:data,
        })
    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
//
self.delete =async(req,res)=>{
    try{
        let email = req.query.email;
        let data = await Video.destroy({
            where: {
                email: email
              },
        });
        return res.json({
          status: "ok",
          message: "Video deleted successfully",data
        });
    }catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}
module.exports = self;