// Load express framework
const express = require('express');
const bodyParser = require('body-parser');
//auth 
const passport = require("passport");
const session = require("express-session");
const env = require("dotenv");
//neccessary evil
var video_ctrl = require('./controllers/video_ctrl');
const {Video,} = require("./models");
//auth


// Initialize the app
const app = express();
const upload = require('./upload');

//
app.use('/Images',express.static('Images'))
app.use('/video',express.static('video'))
// Configure the server to parse the JSON data coming from the client
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
//

// Configure server port
const port = process.env.PORT || 3001;
const secret = process.env.SECRET || 'CAT';
app.use(session({
    secret:secret,
    resave:true,
    saveUninitialized:true
}))
app.use(passport.initialize());
app.use(passport.session());
//models
const models = require('./models');

//const models = require('./models');
const db = require("./models");
db.sequelize.sync({force:false});
// Routes
const route = require('./routes/routes');
var authRoute = require('./routes/auth_routes');
//authRoute(app, passport);
require('./passport/passport')(passport,models.User);

//var authRoute = require('./routes/auth_routes')(app,passport);
//load passport strategies
//require('./passport/passport.js')(passport,models.Member)
const videoUpload = async(req,res,next)=>{
try{
// Extract necessary details from the uploaded file and request body
const { originalname } = req.file;
const { title, publisher, producer, genre, age_rating, user_id } = req.body;
 // Prepare an object with the video details
 const videoDetails = {
    title: originalname,
    publisher: publisher,
    producer: producer,
    genre: genre,
    age_rating: age_rating,
    user_id: user_id,
    // Add other relevant details here based on your model structure
    // Example: filename: originalname, etc.
  };
  //console.log(videoDetails);
  let data = await Video.create(videoDetails);
  return res.json({
    status:"ok",
    data:data,
})
 // Save video details to the database using the video_ctrl.save function
 //const savedVideo = await video_ctrl.save(videoDetails);

 // Pass the saved video data to the next middleware or route handler
 req.savedVideo = savedVideo;
next();
}catch(error){
        res.status(500).json({
            status:"error",
            data:error
        })
    }
}

app.use("/api_v1",route(express));
app.set("view engine","ejs")
app.get('/', (req, res) => {
    res.render("login");
});
app.get('/creator', (req, res) => {
    res.render("creator");
});
app.get('/main', (req, res) => {
    res.render("main");
});
app.post('/upload', upload.single('video'),videoUpload, (req, res) => {
    res.json({ message: 'file uploaded' });
});

// Start server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});