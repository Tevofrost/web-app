const fs = require('fs');
const multer = require('multer');
const uploadDirectory = './video';

const storage = multer.diskStorage({
    destination:(req,file,cb)=>{
        cb(null , 'video/');

    },
    filename:(req,file,cb)=>{
        cb(null,file.originalname);

    }
});

// Set up storage for movie posters
/*const posterStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'Images/');
    },
    filename: (req, file, cb) => {
      cb(null, file.originalname); // You can adjust the filename as needed
    }
  });
  */
const upload = multer({ storage:storage});
//const uploadPoster = multer({ storage: posterStorage })

module.exports = upload;